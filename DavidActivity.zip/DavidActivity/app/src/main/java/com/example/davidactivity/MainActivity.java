package com.example.davidactivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;


import com.example.davidactivity.Questions;
import com.example.davidactivity.QuizDbHelper;
import com.example.davidactivity.R;


import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    private RadioGroup rbGroup;
    private RadioButton rb1, rb2, rb3, rb4;
    private Button buttonConfirmNext;
    private TextView textViewQuestions, textviewScore, textViewQuestionCount, textViewCountDown, textViewCorrect, textViewWrong;
    private ArrayList<Questions> questionList;
    private int questionCounter = 0;
    private int questionTotalCounter;
    private Questions currentQuestions;
    private boolean answered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupUI();
        fetchDB();
    }

    private void setupUI() {
        textViewCorrect = findViewById(R.id.txtCorrect);
        textViewWrong = findViewById(R.id.txtWrong);
        textViewCountDown = findViewById(R.id.txtViewtimer);
        textViewQuestionCount = findViewById(R.id.txtTotalQuestions);
        textviewScore = findViewById(R.id.txtScore);
        buttonConfirmNext = findViewById(R.id.button);
        rbGroup = findViewById(R.id.radio_group);
        rb1 = findViewById(R.id.radio_button1);
        rb2 = findViewById(R.id.radio_button2);
        rb3 = findViewById(R.id.radio_button3);
        rb4 = findViewById(R.id.radio_button4);
    }

    private void fetchDB() {
        QuizDbHelper dbHelper = new QuizDbHelper(this);
        questionList = dbHelper.getAllQuestions();
        questionTotalCounter = questionList.size();
        Collections.shuffle(questionList);
        showQuestions();

        buttonConfirmNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!answered) {
                    if (rb1.isChecked() || rb2.isChecked() || rb3.isChecked() || rb4.isChecked()) {
                        quizOperations();
                    } else {
                        Toast.makeText(MainActivity.this, "Please select an option", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    private void quizOperations() {
        answered = true;
        RadioButton rbSelected = findViewById(rbGroup.getCheckedRadioButtonId());
        int answerNr = rbGroup.indexOfChild(rbSelected) + 1;
        checkSolution(answerNr, rbSelected);
    }

    private void checkSolution(int answerNr, RadioButton rbSelected) {
        if (currentQuestions.getAnswerNr() == answerNr) {
            rbSelected.setBackground(ContextCompat.getDrawable(this, R.drawable.when_answer_correct));
        } else {
            changetoIncorrectColor(rbSelected);
        }
        showQuestions();
    }

    private void changetoIncorrectColor(RadioButton rbSelected) {
        rbSelected.setBackground(ContextCompat.getDrawable(this, R.drawable.when_answer_wrong));
    }

    private void showQuestions() {
        rbGroup.clearCheck();
        if (questionCounter < questionTotalCounter) {
            currentQuestions = questionList.get(questionCounter);
            textViewQuestions.setText(currentQuestions.getQuestion());
            rb1.setText(currentQuestions.getOption1());
            rb2.setText(currentQuestions.getOption2());
            rb3.setText(currentQuestions.getOption3());
            rb4.setText(currentQuestions.getOption4());
            questionCounter++;
            answered = false;
        }
    }
}
